package com.example.redalert.addressees;

import retrofit2.Call;
import retrofit2.http.GET;

public interface addressS {
    @GET("api/system/address")
    Call<Dom_alot> getData();
}
