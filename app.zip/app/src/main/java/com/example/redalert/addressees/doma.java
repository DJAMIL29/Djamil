package com.example.redalert.addressees;

import android.app.ListActivity;
import android.os.Bundle;
import android.widget.TextView;

import com.example.redalert.R;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class doma extends ListActivity {
    @Override
    protected void onCreate (Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.doma_design);
        final List<Dom> listDoms;
        Gson gson = new GsonBuilder()
                .setLenient()
                .create();
        Retrofit retrofit = new retrofit2.Retrofit.Builder()
                .baseUrl("http://intelligent-system.online/")
                .addConverterFactory(GsonConverterFactory.create(gson))
                .build();
        addressS api = retrofit.create(addressS.class);
        api.getData().enqueue(new Callback<Dom_alot>() {
            @Override
            public void onResponse(Call<Dom_alot> call, Response<Dom_alot> response) {
                if (response.isSuccessful()) {
                    setDataToList(response.body().getList());
                } else {
                    TextView tvv = findViewById(R.id.address_title);
                    tvv.setText(response.message());
                }
            }
            @Override
            public void onFailure(Call<Dom_alot> call, Throwable t) {
                TextView tv = findViewById(R.id.address_title);
                tv.setText("Fail");
            }
        });

    }
    void setDataToList(List<Dom> sss){
        setListAdapter(new MyClassAdapter_ad(this,sss));
    }
}
