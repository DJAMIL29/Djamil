package com.example.redalert;

import android.app.AlertDialog;
import android.app.Dialog;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.fragment.app.DialogFragment;

public class MyDialogF extends DialogFragment {
        @Override
        public Dialog onCreateDialog(final Bundle savedInstanceState){
            final AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
            LayoutInflater inflater = getActivity().getLayoutInflater();
            View view = inflater.inflate(R.layout.dialog_signin,null);
            builder.setView(view);
            Button bt1 = view.findViewById(R.id.b1);
            bt1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Toast toast = Toast.makeText(getContext(),"FVCK",Toast.LENGTH_SHORT);
                    toast.show();
                }
            });
            Button bt2 = view.findViewById(R.id.b2);
            bt2.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    dismiss();
                }
            });

            return builder.create();
        }

}
