package com.example.redalert.addressees;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Dom_alot {
    @SerializedName("addresses")
    public List<Dom> dd;

    public List<Dom> getList(){
        return this.dd;
    }

}